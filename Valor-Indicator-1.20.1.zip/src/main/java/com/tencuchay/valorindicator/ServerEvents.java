package com.tencuchay.valorindicator.server;

import com.tencuchay.valorindicator.ValorIndicator;
import com.tencuchay.valorindicator.network.IndicatorPacket;
import com.tencuchay.valorindicator.network.ValorNetwork;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * Runs on the logical server (dedicated server, or the integrated server in singleplayer).
 * Works out the final damage / heal amount and tells every player who can see the entity.
 */
@Mod.EventBusSubscriber(modid = ValorIndicator.MOD_ID)
public final class ServerEvents {

    /**
     * valor_items writes the game time of its last critical hit into the target's persistent data
     * under this key (a long). If it equals the current game time, this hit was a crit.
     */
    private static final String VALOR_CRIT_KEY = "ValorLastCritTick";

    // Absorption hearts before the hit, so damage soaked up by them is still shown.
    private static int hurtEntityId = -1;
    private static float absorptionBefore = 0f;

    private ServerEvents() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide()) return;

        hurtEntityId = victim.getId();
        absorptionBefore = victim.getAbsorptionAmount();
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingDamage(LivingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide()) return;

        float total = event.getAmount();
        if (hurtEntityId == victim.getId()) {
            float absorbed = absorptionBefore - victim.getAbsorptionAmount();
            if (absorbed > 0f) total += absorbed;
        }
        hurtEntityId = -1;

        if (!(total > 0f)) return; // also filters NaN

        // Damage types listed in the client config are turned into "crit" on the client side.
        send(victim, total, damageTypeId(event.getSource()), wasValorCrit(victim), false);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onLivingHeal(LivingHealEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;

        // Only count what is actually restored (ignore overheal at full health).
        float healed = Math.min(event.getAmount(), entity.getMaxHealth() - entity.getHealth());
        if (!(healed > 0f)) return;

        send(entity, healed, "heal", false, true);
    }

    private static boolean wasValorCrit(LivingEntity victim) {
        CompoundTag data = victim.getPersistentData();
        return data.contains(VALOR_CRIT_KEY, Tag.TAG_LONG)
                && data.getLong(VALOR_CRIT_KEY) == victim.level().getGameTime();
    }

    private static String damageTypeId(DamageSource source) {
        return source.typeHolder().unwrapKey()
                .map(key -> key.location().toString())
                .orElse("unknown");
    }

    private static void send(LivingEntity entity, float amount, String typeId, boolean crit, boolean heal) {
        IndicatorPacket packet = new IndicatorPacket(
                entity.getX(), entity.getY() + entity.getBbHeight(), entity.getZ(),
                amount, typeId, crit, heal);
        ValorNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> entity), packet);
    }
}
