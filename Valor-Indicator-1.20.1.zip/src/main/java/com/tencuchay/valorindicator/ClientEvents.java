package com.tencuchay.valorindicator.client;

import com.tencuchay.valorindicator.ValorIndicator;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ValorIndicator.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {

    private ClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            IndicatorManager.clear();
            return;
        }
        if (mc.isPaused()) return;

        IndicatorManager.tick();
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        // Drawn after clouds and weather so nothing in the world is painted over the numbers.
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_WEATHER) return;

        IndicatorRenderer.render(event.getCamera(), event.getPartialTick());
    }
}
